Your task: find `treasure.txt` inside the maze of directories.

General instructions: upon entering a new directory (a room in the maze) always run `cat README` to
read the description of the room, learn something new, and get a clue about how to proceed.

To begin:
- run `ls -a` (without the backticks) in this directory.
- notice the subdirectory appears, whose name begins with a dot
- enter it
